document.addEventListener("DOMContentLoaded", (event) => {
  setTimeout(function () {
    document.querySelector("ul.messages").style.display = "none";
  }, 3000);
});
